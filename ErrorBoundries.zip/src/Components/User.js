import React, { useState } from 'react'

const User = () => {
    const [count, setCount] = useState(0);
    if(count===3){
        throw new Error('too much count...');
    }
    const handleIncrement = () => {
        setCount(count+1)
    }
    return (
        <div>
            <h2>{count}</h2>
            <button onClick={handleIncrement}>increment</button>
        </div>
    )
}

export default User
