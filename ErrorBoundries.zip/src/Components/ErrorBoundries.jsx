import React, { Component } from 'react'

export class ErrorBoundries extends Component {
    state = {
        error: '',
    }
   static getDerivedStateFromError(error) {
        return {
            error: error,
        }
    }
    componentDidCatch(error, info) {
        console.error('error is : ', error);
        console.error('info is : ', info);
    }
    render() {
        if (this.state.error) {
            return (
                <div>
                    <h1>some error occur....</h1>
                </div>
            )

        }
        return this.props.children

    }
}
export default ErrorBoundries
