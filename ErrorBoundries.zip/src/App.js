import ErrorBoundries from "./Components/ErrorBoundries";
import User from "./Components/User";


function App() {

  return (

    <div className='bg-blue-100 flex flex-col justify-center items-center'>
      all is working good.....
      <ErrorBoundries>
        <User />
      </ErrorBoundries>
    </div>
  );
}

export default App;
